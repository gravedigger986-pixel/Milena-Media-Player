#!/bin/bash
set -e
echo ">>> Building Milena Flatpak for GNOME Software"
sudo dnf install -y flatpak flatpak-builder
flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
flatpak install -y flathub org.gnome.Platform//46 org.gnome.Sdk//46
flatpak-builder --force-clean --repo=repo build-dir org.gnome.Milena.json
flatpak build-bundle repo milena-player.flatpak org.gnome.Milena
echo "✅ ГОТОВО! Файл milena-player.flatpak - открой двойным кликом, откроется в Software Manager"
